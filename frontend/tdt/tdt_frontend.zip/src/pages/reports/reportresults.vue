<template>
  <q-page padding>
    <leftDrawer />
    <template>
  <div class="q-pa-md">
    <q-table
      title="Search Results"
      :data="searchResults"
      :columns="columns"
      :visible-columns="visibleColumns"
      row-key="id"
    >
    </q-table>
  </div>
  <div class="q-pa-md">
    <q-btn class="glossy" rounded color="indigo-12" label="Generate Report" @click="generateReport()" />
  </div>

  <pre>{{ this.$q.localStorage.getItem('searchParams') }}</pre>

</template>

  </q-page>
</template>

<script>
import { mapGetters } from 'vuex'
import { parse } from 'json2csv'

const fields = ['ProjectIdentifier', 'RegionName', 'DistrictName', 'ProjectOfficerName', 'ApplicationDate', 'ProjectName', 'AmountGrantRequested', 'AmountGrantRecommended', 'AmountGrantApproved', 'StatusDescription', 'ProjOfficerRecommendation', 'ProjectDescription', 'Summary', 'StatusCode', 'DateGrantApproved', 'AmountGrantPaid', 'DateGrantPaid', 'TargetCompletionDate', 'Keywords', 'Problems', 'StatusCodeDate', 'StrengthsWeaknesses', 'FinanceOtherFunders', 'LocalContribution', 'WebSitePicture', 'WebSitePictureDescription', 'Latitude', 'Longitude', 'DocumentsUrl', 'PublicDocumentsUrl', 'ImpactOfProject', 'LastUpdated', 'TotalProjectCost', 'LastUpdatedBy']
const opts = { fields }

export default {
  data: () => ({
    visibleColumns: ['identifier', 'name', 'region', 'keywords', 'projectofficer', 'statuscode'],
    props: ['id', 'name', 'view'],
    selectedCategory: {},
    columns: [
      {
        name: 'id',
        label: 'Id',
        field: 'Id',
        align: 'left'
      },
      {
        name: 'identifier',
        label: 'Project Identifier',
        field: 'ProjectIdentifier',
        align: 'left'
      },
      {
        name: 'name',
        label: 'Project Name',
        field: 'ProjectName',
        align: 'left'
      },
      {
        name: 'region',
        label: 'Region',
        field: 'RegionName',
        align: 'left'
      },
      {
        name: 'keywords',
        label: 'Keywords',
        field: 'Keywords',
        align: 'left'
      },
      {
        name: 'projectofficer',
        label: 'Project Officer',
        field: 'ProjectOfficerName',
        align: 'left'
      },
      {
        name: 'statuscode',
        label: 'Status',
        field: 'StatusCode',
        align: 'left'
      }
    ],
    searchParams: {},
    json_data: []
  }),
  mounted () {
    if (!this.$store.getters['users/user']) {
      this.$router.push('/notuser')
    } else {
      if (!this.$store.getters['users/user'].Email) {
        this.$router.push('/notuser')
      }
    }
    this.$store.dispatch('projects/loadProjects')
    this.$store.dispatch('regions/loadRegions')
    this.$store.dispatch('ngos/loadNGOs')
    this.$store.dispatch('projectOfficers/loadProjectOfficers')
    this.$store.dispatch('statusCodes/loadStatusCodes')
    this.$store.dispatch('funders/loadFunders')
    this.$store.dispatch('categories/loadCategories')
    this.$store.dispatch('districts/loadDistricts')
    this.$store.dispatch('otherBodies/loadOtherBodies')
    this.$store.dispatch('projects/searchProjects', this.$q.localStorage.getItem('searchParams'))
    this.searchParams = this.$q.localStorage.getItem('searchParams')
  },
  computed: {
    ...mapGetters({
      searchResults: 'projects/searchResults'
    })
  },
  methods: {
    viewProject (rowId) {
      this.$q.localStorage.set('selectedProjectId', rowId)
      this.$router.push('/project/details')
    },
    generateReport () {
      const header = this.buildHeader()
      const csv = parse(this.searchResults, opts)
      var hiddenElement = document.createElement('a')
      hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(header + '\r\n' + csv)
      hiddenElement.target = '_blank'
      hiddenElement.download = 'report.csv'
      hiddenElement.click()
      hiddenElement.remove()
    },
    buildHeader () {
      var searchHeader = ''
      if (this.searchParams.Identifier !== '') {
        searchHeader += 'Project Identifier, ' + this.searchParams.Identifier + ','
      }
      if (this.searchParams.Name !== '') {
        searchHeader += 'Project Name,' + this.searchParams.Name + ','
      }
      if (this.searchParams.Keywords !== '') {
        searchHeader += 'Keywords,' + this.searchParams.Keywords + ','
      }
      if (this.searchParams.RegionID !== 0) {
        searchHeader += 'Region,' + this.getRegion(this.searchParams.RegionID) + ','
      }
      if (this.searchParams.NGOId !== 0) {
        searchHeader += 'NGO,' + this.getNGO(this.this.searchParams.NGOId) + ','
      }
      if (this.searchParams.OfficerId !== 0) {
        searchHeader += 'Project Officer,' + this.getProjOfficer(this.searchParams.OfficerId) + ','
      }
      if (this.searchParams.Status !== 0) {
        searchHeader += 'Status Code,' + this.getStatusCode(this.searchParams.Status) + ','
      }
      if (this.searchParams.FunderId !== 0) {
        searchHeader += 'Funder,' + this.getFunder(this.searchParams.FunderId) + ','
      }
      if (this.searchParams.DistrictId !== 0) {
        searchHeader += 'District,' + this.getDistrict(this.searchParams.DistrictId) + ','
      }
      if (this.searchParams.CategoryId !== 0) {
        searchHeader += 'Category,' + this.getCategory(this.searchParams.CategoryId) + ','
      }
      if (this.searchParams.OtherBodyId !== 0) {
        searchHeader += 'Other Body,' + this.getOtherBody(this.searchParams.OtherBodyId)
      }
      return searchHeader
    },
    getRegion (regionId) {
      return this.$store.getters['regions/getRegionById'](regionId).Name
    },
    getDistrict (districtId) {
      return this.$store.getters['districts/getDistrictById'](districtId).Name
    },
    getProjOfficer (officerId) {
      return this.$store.getters['projectOfficers/getProjectOfficerById'](officerId).FullName
    },
    getNGO (NGOId) {
      return this.$store.getters['ngos/getNGOById'](NGOId).Name
    },
    getStatusCode (statusCodeId) {
      return this.$store.getters['statusCodes/getStatusCodeById'](statusCodeId).StatusCode
    },
    getFunder (funderId) {
      return this.$store.getters['funders/getFunderById'](funderId).FullName
    },
    getCategory (catId) {
      return this.$store.getters['categories/getCategoryById'](catId).CategoryName
    },
    getOtherBody (otherBodyId) {
      return this.$store.getters['otherbodies/getOtherBodyById'](otherBodyId).Name
    }
  },
  components: {
    'leftDrawer': require('components/plainLeftDrawer.vue').default
  }
}

</script>
