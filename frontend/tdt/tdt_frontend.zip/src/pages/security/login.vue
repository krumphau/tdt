// src/pages/Login.vue

<template>
  <q-page padding class="">
    <q-card >
  <q-card-title>
    Press the 'Login' button to login with your Microsoft account
  </q-card-title>
  <q-card-separator />
  <q-card-actions align="center">
    <q-btn color="primary" align="center" label="Log In" @click="submit" />
  </q-card-actions>
</q-card>
</q-page>
</template>

<script>
/* import { required, email } from 'vuelidate/lib/validators' */

export default {
  data () {
    return {
      form: {
        email: '',
        password: ''
      },
      user: {}
    }
  },
  /* validations: {
    form: {
      email: { required, email },
      password: { required }
    }
  }, */
  methods: {
    submit () {
      if (!this.$msal.isAuthenticated()) {
        alert('Signing in')
        this.$msal.signIn()
      }
      this.user = {
        ...this.$msal.data.user
      }
      /* this.$v.form.$touch()

      if (this.$v.form.$error) {
        this.$q.notify('Please review fields again.')
      }
      this.$store.dispatch('user/login', {
        email: this.form.email,
        password: this.form.password,
        strategy: 'local'
      }).then(() => {
        this.$router.push('/')
      }) */
    }
  }
}
</script>
