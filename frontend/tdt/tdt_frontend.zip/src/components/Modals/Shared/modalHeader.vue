<template>
    <q-card-section>
        <div class="text-h6"><slot></slot></div>
    </q-card-section>
</template>

<script>
export default {
}
</script>
