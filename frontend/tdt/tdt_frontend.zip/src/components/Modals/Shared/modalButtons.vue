<template>
    <q-card-actions align="right" class="text-primary">
                <q-btn class="glossy" rounded color="indigo-12" label="Cancel" v-close-popup />
                <q-btn class="glossy" rounded color="indigo-12" label="Save" type="submit" />
    </q-card-actions>
</template>

<script>
export default {

}
</script>
